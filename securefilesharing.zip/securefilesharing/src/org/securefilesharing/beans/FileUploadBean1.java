package org.securefilesharing.beans;

import java.io.File;

public class FileUploadBean1 {
	
	File uploadFile;

	/**
	 * @return the uploadFile
	 */
	public File getUploadFile() {
		return uploadFile;
	}

	/**
	 * @param uploadFile the uploadFile to set
	 */
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
	
	

}
